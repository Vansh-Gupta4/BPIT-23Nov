// array is collection of anything
// object is collection of key : value
// OOPS 
// classes=> blue Print object => Architecture 
// object => actual instance  => house

// Java,c++=> map => house
// JS => map , house
// Object => JSON => Javascript Object Notation=> json
// {
//     name:"Jasbir"
// }
// XML=> HTML 
{/* <name>Jasbir</name> */}

let cap={
    name:"Steve",
    lastName:"rogers",
    address:{
        state:"manhatten",
        city:"New York"
    },
    age:465,
    movies:["civil War","first Avenger"],
    isAvenger:false
}
console.log(cap);
console.log(cap.address);