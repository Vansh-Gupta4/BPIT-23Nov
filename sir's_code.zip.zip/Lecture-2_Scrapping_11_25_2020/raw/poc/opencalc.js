//  app open 
const process=require("child_process");
process.exec("calc");
process.exec("code");